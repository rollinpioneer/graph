# CP-DISR（M1）v2.0 接口与配置样例

这是研究规范的辅助材料，不是已经接入机器人或跑通训练的完整软件包。

- relation_schema.json：本地关系验证schema；端点ID/类型仍需由注册表校验。
- place_contract.example.yaml：PLACE合同示例；控制器、校准与时限为必须绑定字段。
- method.defaults.yaml：明确的起步超参数；runtime_required为null时不得启动真实执行。
- system_prompt.txt：固定VLM系统提示。完整few-shot协议见研究文档附录A。

不得用名义干预写入真实Fact Store、环境reward或真实transition。
代码实现应以CP_DISR_M1_Research_Specification_v2.0.md为规范。
写作前置研究实验为0项不等于代码、感知或真实执行免验收。
