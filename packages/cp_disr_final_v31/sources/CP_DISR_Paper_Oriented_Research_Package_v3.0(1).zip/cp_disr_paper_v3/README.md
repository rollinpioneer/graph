# CP-DISR Paper-Oriented Research Specification v3.0

**文档v3.0；方法仍为CP-DISR / M1 v2.1。**

维护源：CP_DISR_Paper_Oriented_Research_Specification_v3.0.md。
阅读编辑版：同名.docx；数学公式由LaTeX转为Word原生可编辑数学对象。

正文包含41个主体章节、Paper Readiness与3个附录。paper_drafts/保存六份从主文逐字提取的论文草稿；interfaces/包含当前方法manifest、v2关系schema、提示词、原始PLACE合同与runtime绑定模板；figures/包含两份可编辑Mermaid信息流图式源。sources/保留本次用到的上传原件与hash。

这些材料是研究定义和实现依据，不是已接通机器人的训练仓库。未提供实际预算、软件锁、相机或技能执行证据的字段使用MUST_BIND。所有结果模板无假数字。本轮无RL训练、VLM请求或机器人动作；validation/只记录文档与配置检查，不冒充生产算法单测。

较早生成版v2.1规范/实验包的二进制未在本轮挂载，不伪造其hash；本版依据上传源件和对话中已确认的决议整合。节点特征位置、历史预算和软件版本的差异在附录A显式说明。

Future M1+仅在Future Work中简述，未进入当前公式、loss或必跑实验。使用者可直接从paper_drafts/继续写论文，并依照主文模块合同在实际工作树中继续实现。
