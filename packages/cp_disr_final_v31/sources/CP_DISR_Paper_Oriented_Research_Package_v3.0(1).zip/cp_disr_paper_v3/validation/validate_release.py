"""Validate document/interface consistency; not production CP-DISR or RL tests.

Requires PyYAML, jsonschema and lxml. Run from any working directory.
"""
from __future__ import annotations
import copy
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path
from datetime import datetime, timezone

import yaml
import jsonschema
from lxml import etree

ROOT = Path(__file__).resolve().parents[1]
NAME = 'CP_DISR_Paper_Oriented_Research_Specification_v3.0'

def main() -> int:
    checks: list[dict] = []
    errors: list[str] = []
    def check(name: str, okay: bool, detail: str = '') -> None:
        checks.append({'check': name, 'passed': bool(okay), 'detail': detail})
        if not okay:
            errors.append(name)
    md = (ROOT / (NAME + '.md')).read_text(encoding='utf-8')
    check('41_numbered_sections', [int(n) for n in re.findall(r'^# (\d+)\. ', md, re.M)] == list(range(1,42)))
    check('balanced_fenced_blocks', len(re.findall(r'^```', md, re.M)) % 2 == 0)
    check('balanced_display_math', len(re.findall(r'^\$\$$', md, re.M)) % 2 == 0)
    check('no_unintended_control_characters', not any(ord(c) < 32 and c not in '\n\r\t' for c in md))
    check('no_tool_citation_tokens_in_document', not any(t in md for t in ['cite','filecite']))
    for title in ['Abstract v0','Introduction v0','Problem Formulation v0','Method v0','Experimental Setup v0','Discussion v0','Paper Readiness']:
        check('has_' + title, title in md)
    intro = md[md.index('# 36. '):md.index('# 37. ')]
    n_intro = len(re.findall(r'[\u4e00-\u9fff]',intro))
    check('introduction_requested_length', 800 <= n_intro <= 1200, f'{n_intro} Chinese characters')
    for idx, (lang, body) in enumerate(re.findall(r'```(json|yaml)\n(.*?)\n```',md,re.S), 1):
        try:
            json.loads(body) if lang == 'json' else yaml.safe_load(body)
            check(f'main_{lang}_block_{idx}',True)
        except Exception as exc:
            check(f'main_{lang}_block_{idx}',False,str(exc))
    for p in sorted((ROOT / 'interfaces').iterdir()):
        if p.suffix not in ['.json','.yaml']: continue
        try:
            value = json.loads(p.read_text()) if p.suffix == '.json' else yaml.safe_load(p.read_text())
            check('parse_' + p.name,True)
        except Exception as exc:
            check('parse_' + p.name,False,str(exc))
    cfg = yaml.safe_load((ROOT/'interfaces/paper_method_manifest.yaml').read_text())
    check('method_2_1_document_3_0',cfg['method']['version']=='2.1' and cfg['document']['version']=='3.0')
    check('future_not_current',cfg['method']['future_m1_plus_enabled'] is False)
    check('prior_exact_80_20',cfg['prior_training']['original']==.8 and cfg['prior_training']['absent']==.2)
    check('prior_episode_fixed',cfg['prior_training']['fixed_within_episode'] and not cfg['prior_training']['resample_during_ppo'])
    check('no_training_wrong_edges',cfg['prior_training']['artificial_wrong_edges'] is False)
    check('no_static_bypass',not cfg['policy']['static_prior'] and not cfg['policy']['direct_current_GH_context'])
    check('zero_anchor_and_bound',cfg['policy']['zero_anchor'] and cfg['policy']['prior_bound']==.5 and not cfg['policy']['prior_head_bias'])
    check('read_only_nominal_intervention',not cfg['intervention']['writes_real_facts'] and not cfg['intervention']['writes_time_reward_done'] and not cfg['intervention']['virtual_geometry'])
    check('graph_profile',cfg['graph']['shared_encoder'] and cfg['graph']['dropout']==0 and cfg['graph']['hidden_dim']==128 and cfg['graph']['layers']==4)
    check('source_models_frozen',cfg['vlm']['trainable'] is False and cfg['vlm']['semantic_retry'] is False)
    check('real_target_detached',cfg['value_learning']['target_detach'] and '1-terminated' in cfg['value_learning']['Q_target'] and 'real_next_snapshot' in cfg['value_learning']['Q_target'])
    check('selected_action_only',cfg['value_learning']['Q_executed_action_only'] and cfg['value_learning']['Q_auxiliary_only'])
    check('no_relation_truth_supervision',not cfg['value_learning']['relation_correctness_supervision'])
    check('independent_V',cfg['value_learning']['independent_V'])
    check('recompute_graphs_and_prefix',cfg['ppo']['recompute_graphs'] and cfg['ppo']['recompute_current_parameter_prefix'])
    check('bootstrap_does_not_commit_hidden',not cfg['ppo']['bootstrap_forward_commits_hidden'])
    check('runtime_budget_not_invented',all(cfg['ppo'][k]=='MUST_BIND' for k in ['total_transition_budget','total_task_time_budget','evaluation_interval','checkpoint_interval']))
    variants=cfg['variants']
    check('exact_seven_variants',set(variants)=={'B0','B1','B2','Full','A_DD','A_Q','A_B'})
    check('A_DD_preserves_absent_interface',variants['A_DD']['nonempty_prior_input']=='D_H' and variants['A_DD']['empty_prior_input']=='zero')
    check('A_Q_only_zero_weight',variants['A_Q']['q_coef']==0 and variants['A_Q']['only_change']=='q_loss_coefficient')
    check('A_B_retains_anchor',variants['A_B']['only_change']=='remove_tanh' and variants['A_B']['zero_anchor_retained'])
    check('evidence_not_claimed',cfg['evidence_state']=={'new_rl_runs':0,'new_vlm_calls':0,'robot_commands':0,'production_unit_tests_run':False,'method_benefit_claimed':False})
    schema=json.loads((ROOT/'interfaces/relation_schema.json').read_text())
    jsonschema.Draft202012Validator.check_schema(schema)
    check('schema_itself_valid',True)
    valid={'schema_version':'m1_soft_relations_v2','relations':[{'relation_id':'r','type':'SOFT_SUPPORTS','source_ref':'a:A','target_ref':'a:B','effect_fact_ref':'p:q'}]}
    jsonschema.validate(valid,schema)
    jsonschema.validate({'schema_version':'m1_soft_relations_v2','relations':[]},schema)
    check('schema_accepts_format_valid_examples',True,'Synthetic IDs test JSON structure only; does not verify real registry.')
    for name, change in [('order',lambda x:x['relations'][0].update(type='SOFT_ORDER')),('missing_effect',lambda x:x['relations'][0].pop('effect_fact_ref')),('new_nodes',lambda x:x.update(nodes=[])),('extra_confidence',lambda x:x['relations'][0].update(confidence=.9))]:
        bad=copy.deepcopy(valid); change(bad)
        try:
            jsonschema.validate(bad,schema)
            check('schema_rejects_'+name,False)
        except jsonschema.ValidationError:
            check('schema_rejects_'+name,True)
    check('only_two_soft_types',set(schema['properties']['relations']['items']['properties']['type']['enum'])=={'SOFT_SUPPORTS','SOFT_RELEVANT_TO_GOAL'})
    sm=json.loads((ROOT/'sources/source_manifest.json').read_text())
    for src in sm['source_files']:
        p=ROOT/'sources'/src['filename']
        check('source_hash_'+src['filename'], p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==src['sha256'])
    with zipfile.ZipFile(ROOT/'sources/CP_DISR_M1_Implementation_Interfaces_v2.0(1).zip') as z:
        check('PLACE_contract_unchanged',(ROOT/'interfaces/place_contract.example.yaml').read_bytes()==z.read('M1_research_support/place_contract.example.yaml'))
    for no,name in [(35,'Abstract_v0'),(36,'Introduction_v0'),(37,'Problem_Formulation_v0'),(38,'Method_v0'),(39,'Experimental_Setup_v0'),(40,'Discussion_v0')]:
        expected=md[md.index(f'# {no}. '):md.index(f'# {no+1}. ')].strip()+'\n'
        check('draft_synced_'+name,(ROOT/'paper_drafts'/f'{name}.md').read_text()==expected)
    check('18_primary_reference_entries',set(int(n) for n in re.findall(r'^\[R(\d+)\]',md,re.M))==set(range(1,19)))
    check('correct_forward_return_arity','dist_old, V_old, _, h_next <- FORWARD' in md)
    check('explicit_bootstrap_parameters','FORWARD(X_next, theta_old, h_next, True, False).V' in md)
    check('GRU_input_uses_original_base','observation_fusion_and_GRU(X.base_input, prefix_hidden)' in md)
    check('unmeasured_result_templates','NOT_MEASURED' in md and '不能替换为0' in md)
    check('no_result_csv_generated',not list(ROOT.glob('**/*metrics.csv')))
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
    with zipfile.ZipFile(ROOT/(NAME+'.docx')) as z:
        xml=etree.fromstring(z.read('word/document.xml'))
        maths=len(xml.findall('.//m:oMath',ns))
        tables=len(xml.findall('.//w:tbl',ns))
        repeated=len(xml.findall('.//w:tblHeader',ns))
        check('native_editable_word_math',maths>100,f'{maths} math objects')
        check('word_tables_have_repeating_headers',tables==repeated,f'{tables} tables; {repeated} headers')
        check('valid_docx_zip',z.testzip() is None)
    visual_path=ROOT/'validation/visual_review.json'
    visual=json.loads(visual_path.read_text()) if visual_path.exists() else {}
    check('all_pages_visually_reviewed',visual.get('reviewed_page_count')==46 and visual.get('render_page_count')==46 and visual.get('passed') is True)
    report={'generated_at':datetime.now(timezone.utc).isoformat(),'scope':'document_and_configuration_consistency_only',
        'method_version':'2.1','document_version':'3.0','checks':checks,'passed':not errors,'errors':errors,
        'production_tests_run':False,'rl_training_run':False,'vlm_requests':0,'robot_commands':0,
        'not_validated':['real registry ID/source adjacency checks','production graph/Actor/V/Q/GRU/PPO','sensor/controller safety','task performance','software compatibility lock'],
        'summary':{'checks':len(checks),'passed_checks':sum(x['passed'] for x in checks),'word_math_objects':maths,'word_tables':tables,'render_pages':46}}
    (ROOT/'validation/validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report['summary']|{'passed':report['passed'],'errors':errors},ensure_ascii=False,indent=2))
    return 0 if not errors else 1

if __name__ == '__main__':
    raise SystemExit(main())
