# 39. Experimental Setup v0

我们将在[MUST_BIND：simulator/robot及版本]上的组合技能任务评价CP-DISR。低层技能、控制器、感知与Verifier、任务评价器和安全检查在各高层方法之间共享并固定。任务覆盖共享前置、多对象选择、中间重定位、多目标交互及可恢复状态变化中的已绑定子集，具体对象、时限和初始case清单见[MUST_BIND：task/split manifest]。

主要比较为B0非图Observation/Fact策略、B1仅读当前图策略、B2合同干预以及Full。所有方法获得匹配的原始任务与合同信息，除显式A_Q外保留同来源动作价值辅助监督。消融A_DD在非空prior时以$D^H$替代$D^P$，空prior仍输入0；A_B仅移除tanh。训练使用共同实际交互预算[MUST_BIND：$N_{cap}$、$T_{cap}$]并分别报告实际技能次数与时间。

共享R-GCN默认4层、128维、4 bases、mean aggregation、root transform、逐节点LayerNorm、dropout0。PPO默认学习率$3\times10^{-4}$、clip0.2、GAE0.95、每1024技能转移执行4个epochs，sequence16、minibatch64；$c_V=0.5$、$\lambda_Q=0.1$、$c_H=0.01$、$B=0.5$。实际硬件、软件锁和全部优化覆盖值由运行manifest记录，不能把初值写成已实测配置。

VLM只从初始允许输入生成关系，采用固定snapshot并保存原始输出及hash；训练每episode使用80%原始/20%整份缺省，不人为改错边。探索默认3个训练seed，正式展示每task/seed起步30个评价episode；checkpoint由开发集连续窗口选择。任何task/seed子集选择在Private Paper View manifest中明确，原始运行完整归档。

主要指标为独立任务成功率与原始学习AUC，辅以真实完成时间、逐seed差异和计算成本。机制分析区分同状态分布响应与闭环结果；鲁棒性使用同一checkpoint的五种明确先验条件；组合泛化只改变已见技能/谓词形成的目标或依赖组合。所有经验结论将在真实测量后按相应样本与任务范围表述。
