# 38. Method v0

## 38.1 Overview

CP-DISR将系统分为信息源、结构表示和决策学习三层。合同、实际事实和固定语义关系提供信息；共享图编码与候选名义干预组织结构变化；Actor及实际执行数据支持的价值学习决定如何使用这些变化。算法前向不访问真实未来，反向不修改知识源。

## 38.2 Contract and semantic graph views

我们将grounded动作和命题表示为两类节点，合同的正/负前置、ADD与DEL构成类型边，并加入独立的逆向消息关系。目标通过命题符号与固定索引表达。当前图保留全部相关节点，包括已完成目标、FALSE/UNKNOWN命题和暂时不可执行动作。该结构采用已有规划图表示与schema共享思想，编码底座为标准R-GCN。[R2–R5]

增强图与合同图具有相同节点和事实，仅增加经过schema、ID、效果引用和局部冗余校验的软关系。词表只有SOFT_SUPPORTS和SOFT_RELEVANT_TO_GOAL；effect_fact_ref用于确保source关联到既有名义效果，不创建新事实或赋予真实状态。初始化后的关系内容固定。

## 38.3 Candidate nominal interventions

对允许候选$a_i$，合同生成只读事实副本$\widetilde F_t^i$，表示其名义成功后的ADD/DEL/UNKNOWN变化。相同patch用于合同图和增强图。临时操作不修改实际观测、事实存储、时钟、reward或done，也不预测技能成功概率。它为策略提供候选结构输入，实际失败与耗时随后通过真实经验学习。

## 38.4 Shared encoder and dual difference

四视图由相同$E_\psi$编码为目标对齐矩阵$Z=[z_0;z_1;\ldots;z_m]$，其中$z_0$为全局读出，其余为固定目标行。我们定义

$$
D_i^K=E_\psi(\widetilde G_i^K)-E_\psi(G^K),\qquad
D_i^H=E_\psi(\widetilde G_i^H)-E_\psi(G^H),
$$

$$
D_i^P=D_i^H-D_i^K.
$$

$D_i^P$刻画软关系如何改变编码器对同一名义变化的响应。其数值不等于关系正确率、因果贡献或价值增量。若先验影响与干预可加分离，则交互为零；空prior通过复用合同编码得到严格零差分。该设计排除独立静态VLM动作分数，但不保证学得的特征不利用统计相关性。

## 38.5 Skill policy

当前观测与历史形成$z_t^o$，候选上下文为$c_i=[z_t^o,e(a_i),\operatorname{Pool}(Z^K)]$。合同候选特征$u_i^K=F_K(c_i,D_i^K)$产生基础logit$b_i$。先验特征采用相同上下文的零输入锚定：

$$
u_i^P=F_P(c_i,u_i^K,D_i^P)-F_P(c_i,u_i^K,0),
\qquad \ell_i=b_i+B\tanh(w_P^\top u_i^P).
$$

该结构使$D_i^P=0$时先验残差为0，并限制其直接幅度。残差可以为正、负或接近零；是否学会相应条件化行为需要实验。动作从独立执行mask上的softmax分布产生，不允许先验改变执行资格。

## 38.6 Outcome-grounded learning

Actor、V和Q是共享部分特征的不同输出头。Q读取指定候选及候选集合背景，仅对实际执行动作$a_t$回归

$$
y_t^Q=\operatorname{sg}\left[r_t+\Gamma_t(1-\mathrm{terminated}_t)V_{old}(X_{t+1})\right].
$$

该目标由实际转移支持但含bootstrap误差；未执行候选不填标签。Q损失更新共享表示，不直接识别某条关系是否错误，也不直接更新Actor最终头。PPO采用时长折扣的GAE、独立V回归和熵正则，总目标为

$$
\mathcal L=-L_{clip}+c_V\mathcal L_V+\lambda_Q\mathcal L_Q-c_H\mathbb E[\mathcal H(\pi)].
$$

源合同、VLM、缓存、Verifier和控制器冻结；可训练的图、观测、候选与输出头联合优化。该监督针对固定先验的决策用途，而非知识修订。

## 38.7 Training and inference

训练按照Algorithm 1交替采样真实技能转移与PPO更新，固定每episode先验并保存历史mask、节点索引和原始输入。优化阶段以当前参数重算图特征与GRU前缀，不用缓存旧差分作为新模型输入，也不重新查询VLM。真实终止不bootstrap，有效外截断使用末状态；名义视图始终不写入环境。

推理时参数冻结，Actor根据当前事实与候选重复上述结构计算；V/Q输出非动作选择必需。执行后的实际证据更新事实和历史，下一次决策重新编码同一关系在新状态下的作用。系统因此具有真实观察—决策—执行闭环，但没有自动修图闭环。
