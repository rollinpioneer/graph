# External artifact collection placeholder

- Original directory: `artifacts/pathgraph_sarm/upgrade_v2/u4_bplus_v1/torch_recovery_v2/data/confirmation/`
- Original files: 48 JSON rollout files retaining their generated episode filenames.
- Total size: 5615610 bytes
- Ordered file-checksum manifest SHA256: `f21f275cc31bc7702088c4e2f03ca2b532d0fb200dde5563db05bf219d8217e9`
- Purpose: frozen confirmation family indices 60-71, four rollout seeds per family, including snapshots and evaluator event sets.
- Restore: rerun `collect-rollouts` from `confirmation_family_plan.jsonl` after `verify-final-lock` passes.
