# CP-DISR（M1）v2.1 接口与配置样例

这是研究规范的辅助材料，不是已接入机器人或跑通训练的软件包。v2.0原件保留。

本次只冻结两个决定：纯交互DP（无静态prior），以及训练时episode级80%原始/20%整份空先验。

- relation_schema.json：只允许SOFT_SUPPORTS和后果关联的SOFT_RELEVANT_TO_GOAL，必填effect_fact_ref。JSON Schema之外仍须校验ID、端点类型、source效果出处、已有ADD/DEL邻接及局部冗余。
- place_contract.example.yaml：与v2.0逐字相同，真实控制器、阈值和时限仍须绑定。
- method.defaults.yaml：训练只有episode_prior_dropout；测试扰动参数另在prior_evaluation中。
- system_prompt.txt：新冻结提示；正式缓存需要新prompt/schema hash，不能将旧输出改版本号冒充新缓存。
- evaluation_protocol.md：只在冻结checkpoint测试缺边、类型保持target swap及合格无关边。
- test_toy_differences.py：标准库可运行的四个线性toy夹具；不是生产R-GCN测试或RL实验。
- CHANGELOG.md：替换范围、输入权限、实验矩阵与验收边界。

规范源为CP_DISR_M1_Research_Specification_v2.1.md。不得用名义图写真实事实、reward或transition。
运行toy检查：`python test_toy_differences.py`。
写作前置研究实验0项不等于运行或安全免验收。
