# v2.1 Change Log

## 两个唯一主决定

1. 保持DP=(H_after-H_before)-(K_after-K_before)。无static prior branch；无当前GH局部embedding绕过DP。
2. 训练episode起点80%原始/20%整份空prior，PPO重算不重抽；不训练边删除/目标交换/语义改写。

## 关系与接口

删除SOFT_ORDER及其反向消息关系ID。只保留SOFT_SUPPORTS和后果关联的SOFT_RELEVANT_TO_GOAL。
旧optional_mediating_fact_ref删除，替换成必须属于source注册效果且已有ADD/DEL邻接的effect_fact_ref。纯UNKNOWN且无ADD/DEL邻接的效果不作为该锚点，但名义干预仍支持UNKNOWN。该字段只作metadata，不额外作为网络输入或逻辑效果。
原schema名m1_soft_relations_v1由m1_soft_relations_v2替换。旧prompt/cache hash不能复用；旧模型relation ID/参数表也不能仅改名视为新版本。
合同样例保持原样；不新增真实MOVE合同或At谓词，文档中的MOVE/At仅为有明确假设的toy/few-shot占位说明。

## 删除旧训练项

删除prior_training.deletion: 0.15和prior_training.relation_rewrite: 0.15。
原prior_training.original: 0.50替换为0.80，absent维持0.20。所有先验消费者基线共享80/20。
测试使用edge_deletion、type_preserving_target_swap、irrelevant_edge_addition的明确规则；不使用无算法的relation rewrite。

## 学习与实验

Actor/V/Q、奖励、PPO、标准R-GCN和Verifier主结构不变。dropout仅为共享输入缺省协议，不是第4项贡献。
最小受控训练矩阵为B0、B1、B2、Full、A_DD、A_Q、A_B；A_DD替代旧独立B3的必跑位置，但不冒称其为单图方法。
不强制Full-clean-train，不宣称dropout独立有效；不新增static-prior ablation。

## 验收边界

附带测试只验证线性toy中的差分恒等式、消息路径见证和schema/config基本一致性。它不验证实际R-GCN学习后的DP幅度、策略表现、语义正确性、感知或机器人安全。
没有运行RL、调用VLM、修改外部仓库或执行机器人。
