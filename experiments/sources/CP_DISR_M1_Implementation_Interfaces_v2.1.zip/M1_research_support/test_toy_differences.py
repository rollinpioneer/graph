"""Four algebraic toy fixtures; not a production R-GCN or an RL experiment."""
import unittest


def propagation_matrix(n, undirected_pairs):
    matrix = [[float(i == j) for j in range(n)] for i in range(n)]
    for source, target in undirected_pairs:
        matrix[target][source] += 1.0
        matrix[source][target] += 1.0
    return matrix


def encode(matrix, state, layers=4):
    value = list(state)
    for _ in range(layers):
        value = [sum(weight * x for weight, x in zip(row, value)) for row in matrix]
    return value


def difference(matrix_k, matrix_h, before, after, layers=4):
    kb, ka = encode(matrix_k, before, layers), encode(matrix_k, after, layers)
    hb, ha = encode(matrix_h, before, layers), encode(matrix_h, after, layers)
    dk = [a - b for a, b in zip(ka, kb)]
    dh = [a - b for a, b in zip(ha, hb)]
    return dk, dh, [h - k for h, k in zip(dh, dk)]


class DifferentialToyTests(unittest.TestCase):
    def setUp(self):
        # OPEN, Open(box), PLACE, Inside(blue,box).
        self.k = propagation_matrix(4, [(0, 1), (1, 2), (2, 3)])
        self.h = propagation_matrix(4, [(0, 1), (1, 2), (2, 3), (0, 2)])
        self.before = [0.0, 0.0, 0.0, 0.0]
        self.after = [0.0, 1.0, 0.0, 0.0]

    def test_case1_no_prior(self):
        dk, dh, dp = difference(self.k, self.k, self.before, self.after)
        self.assertEqual((dk[3], dh[3], dp[3]), (9.0, 9.0, 0.0))
        self.assertEqual(dp, [0.0] * 4)

    def test_case2_supports_path_and_contract_dedup(self):
        dk, dh, dp = difference(self.k, self.h, self.before, self.after)
        self.assertEqual((dk[3], dh[3], dp[3]), (9.0, 14.0, 5.0))
        self.assertEqual(difference(self.k, self.h, self.before, self.after, 2)[2][3], 0.0)
        self.assertEqual(difference(self.k, self.h, self.before, self.after, 3)[2][3], 1.0)
        # Production dedup would remove this contract-redundant semantic edge.
        self.assertEqual(difference(self.k, self.k, self.before, self.after)[2], [0.0] * 4)

    def test_case3_old_order_type_is_not_algebraically_dead(self):
        # Equal numerical relation weights => the same walk response. The new
        # production schema rejects ORDER; this is an old-schema diagnostic only.
        self.assertEqual(difference(self.k, self.h, self.before, self.after)[2][3], 5.0)

    def test_case4_goal_relation_and_empty_patch(self):
        # MOVE, its registered effect q, and goal g. No K path from q to g.
        k = propagation_matrix(3, [(0, 1)])
        h = propagation_matrix(3, [(0, 1), (0, 2)])
        before, after = [0.0] * 3, [0.0, 1.0, 0.0]
        dk, dh, dp = difference(k, h, before, after)
        self.assertEqual((dk[2], dh[2], dp[2]), (0.0, 8.0, 8.0))
        self.assertEqual(difference(k, h, before, after, 2)[2][2], 1.0)
        self.assertEqual(difference(k, h, after, after), ([0.0] * 3,) * 3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
