# 本次文件与toy验收记录

- 四个线性toy单元测试：4/4通过。无prior时DP为0；支持/旧顺序边的传播见证为非零；MOVE非局部goal关系存在两跳路径；空patch时全部差分为0。
- 新JSON Schema自身通过Draft 2020-12结构检查；合法格式样例通过；SOFT_ORDER与缺少effect_fact_ref的样例均被拒绝。
- 训练配置只保留original/absent两种采样权重，和为1；static prior为false；配置不含训练deletion或relation_rewrite。
- 研究文档内7个JSON/YAML代码块均可解析；PLACE合同样例与v2.0原包逐字节相同。

这些检查没有验证真实ID/效果邻接的完整注册表validator，也没有验证生产R-GCN、PPO、V/Q、感知或机器人执行。没有运行RL或调用VLM。
